"use client";

import {
  ChangeEvent,
  CSSProperties,
  useEffect,
  useMemo,
  useState,
} from "react";

import type { Food } from "@/lib/foods";

type FoodDatabaseProps = {
  foods: Food[];
};

type SortOption =
  | "relevant"
  | "protein-high"
  | "calories-low"
  | "calories-high"
  | "alphabetical";

const IMPORTED_FOODS_STORAGE_KEY = "start_imported_foods";

function normalizeText(value: string): string {
  return value
    .toLocaleLowerCase("he")
    .replace(/[׳']/g, "")
    .replace(/\s+/g, " ")
    .trim();
}

function isFood(value: unknown): value is Food {
  if (!value || typeof value !== "object") {
    return false;
  }

  const food = value as Partial<Food>;

  return (
    typeof food.id === "string" &&
    typeof food.name === "string" &&
    typeof food.category === "string" &&
    typeof food.calories === "number" &&
    typeof food.protein === "number" &&
    typeof food.carbs === "number" &&
    typeof food.fat === "number" &&
    typeof food.servingLabel === "string"
  );
}

export default function FoodDatabase({
  foods: defaultFoods,
}: FoodDatabaseProps) {
  const [allFoods, setAllFoods] =
    useState<Food[]>(defaultFoods);

  const [searchTerm, setSearchTerm] = useState("");
  const [selectedCategory, setSelectedCategory] =
    useState("הכול");

  const [sortBy, setSortBy] =
    useState<SortOption>("relevant");

  const [isImportedDatabase, setIsImportedDatabase] =
    useState(false);

  useEffect(() => {
    try {
      const storedFoods = localStorage.getItem(
        IMPORTED_FOODS_STORAGE_KEY,
      );

      if (!storedFoods) {
        setAllFoods(defaultFoods);
        setIsImportedDatabase(false);
        return;
      }

      const parsedFoods: unknown = JSON.parse(storedFoods);

      if (!Array.isArray(parsedFoods)) {
        throw new Error("Imported foods are not an array.");
      }

      const validFoods = parsedFoods.filter(isFood);

      if (validFoods.length === 0) {
        throw new Error("No valid imported foods were found.");
      }

      setAllFoods(validFoods);
      setIsImportedDatabase(true);
    } catch (error) {
      console.error(
        "Failed to load imported foods:",
        error,
      );

      setAllFoods(defaultFoods);
      setIsImportedDatabase(false);
    }
  }, [defaultFoods]);

  const categories = useMemo(
    () => [
      "הכול",
      ...new Set(
        allFoods
          .map((food) => food.category)
          .filter(Boolean),
      ),
    ],
    [allFoods],
  );

  const filteredFoods = useMemo(() => {
    const normalizedSearch = normalizeText(searchTerm);

    const results = allFoods.filter((food) => {
      const matchesCategory =
        selectedCategory === "הכול" ||
        food.category === selectedCategory;

      const searchableText = [
        food.name,
        food.brand ?? "",
        food.category,
      ]
        .map(normalizeText)
        .join(" ");

      const matchesSearch =
        !normalizedSearch ||
        searchableText.includes(normalizedSearch);

      return matchesCategory && matchesSearch;
    });

    return [...results].sort((firstFood, secondFood) => {
      switch (sortBy) {
        case "protein-high":
          return secondFood.protein - firstFood.protein;

        case "calories-low":
          return firstFood.calories - secondFood.calories;

        case "calories-high":
          return secondFood.calories - firstFood.calories;

        case "alphabetical":
          return firstFood.name.localeCompare(
            secondFood.name,
            "he",
          );

        case "relevant":
        default:
          return 0;
      }
    });
  }, [
    allFoods,
    searchTerm,
    selectedCategory,
    sortBy,
  ]);

  function handleSearchChange(
    event: ChangeEvent<HTMLInputElement>,
  ) {
    setSearchTerm(event.target.value);
  }

  function handleSortChange(
    event: ChangeEvent<HTMLSelectElement>,
  ) {
    setSortBy(event.target.value as SortOption);
  }

  function clearFilters() {
    setSearchTerm("");
    setSelectedCategory("הכול");
    setSortBy("relevant");
  }

  function restoreDefaultFoods() {
    localStorage.removeItem(IMPORTED_FOODS_STORAGE_KEY);

    setAllFoods(defaultFoods);
    setIsImportedDatabase(false);
    clearFilters();
  }

  return (
    <section className="food-database">
      <div className="food-database__header">
        <div>
          <span className="food-database__eyebrow">
            START FOOD DATABASE
          </span>

          <h1 className="food-database__title">
            מאגר מזונות
          </h1>

          <p className="food-database__description">
            חיפוש מהיר לפי שם מאכל, מותג או קטגוריה
          </p>

          <div style={databaseStatusStyle}>
            <span
              style={{
                ...statusDotStyle,
                background: isImportedDatabase
                  ? "#4CAF50"
                  : "#D4AF37",
              }}
            />

            <span>
              {isImportedDatabase
                ? "מאגר מיובא פעיל"
                : "מאגר הדוגמה פעיל"}
            </span>
          </div>
        </div>

        <div className="food-database__count">
          <strong>{filteredFoods.length}</strong>
          <span>תוצאות</span>
        </div>
      </div>

      <div style={toolbarStyle}>
        <div
          className="food-search"
          style={searchWrapperStyle}
        >
          <span
            className="food-search__icon"
            aria-hidden="true"
          >
            🔍
          </span>

          <input
            className="food-search__input"
            type="search"
            value={searchTerm}
            onChange={handleSearchChange}
            placeholder="חפש מאכל או מוצר..."
            aria-label="חיפוש מאכל או מוצר"
            autoComplete="off"
          />

          {searchTerm && (
            <button
              className="food-search__clear"
              type="button"
              onClick={() => setSearchTerm("")}
              aria-label="ניקוי החיפוש"
            >
              ×
            </button>
          )}
        </div>

        <div style={sortContainerStyle}>
          <label
            htmlFor="food-sort"
            style={sortLabelStyle}
          >
            מיון
          </label>

          <select
            id="food-sort"
            value={sortBy}
            onChange={handleSortChange}
            style={sortSelectStyle}
            aria-label="מיון מאכלים"
          >
            <option value="relevant">
              הכי רלוונטי
            </option>

            <option value="protein-high">
              הכי הרבה חלבון
            </option>

            <option value="calories-low">
              קלוריות מהנמוך לגבוה
            </option>

            <option value="calories-high">
              קלוריות מהגבוה לנמוך
            </option>

            <option value="alphabetical">
              לפי סדר א׳–ת׳
            </option>
          </select>
        </div>
      </div>

      <div className="food-categories">
        {categories.map((category) => (
          <button
            key={category}
            type="button"
            className={
              selectedCategory === category
                ? "food-category active"
                : "food-category"
            }
            onClick={() =>
              setSelectedCategory(category)
            }
          >
            {category}
          </button>
        ))}
      </div>

      {isImportedDatabase && (
        <div style={importedNoticeStyle}>
          <span>
            מוצגים {allFoods.length} מוצרים מהמאגר
            שהעלית.
          </span>

          <button
            type="button"
            onClick={restoreDefaultFoods}
            style={restoreButtonStyle}
          >
            חזור למאגר הדוגמה
          </button>
        </div>
      )}

      {filteredFoods.length > 0 ? (
        <div className="food-list">
          {filteredFoods.map((food) => (
            <article
              className="food-card"
              key={food.id}
            >
              <div className="food-card__top">
                <div>
                  <span className="food-card__category">
                    {food.category}
                  </span>

                  <h2 className="food-card__name">
                    {food.name}
                  </h2>

                  {food.brand && (
                    <p className="food-card__brand">
                      {food.brand}
                    </p>
                  )}
                </div>

                <div className="food-card__calories">
                  <strong>{food.calories}</strong>
                  <span>קלוריות</span>
                </div>
              </div>

              <div className="food-card__macros">
                <MacroItem
                  label="חלבון"
                  value={food.protein}
                />

                <MacroItem
                  label="פחמימה"
                  value={food.carbs}
                />

                <MacroItem
                  label="שומן"
                  value={food.fat}
                />
              </div>

              <div className="food-card__footer">
                {food.servingLabel}
              </div>
            </article>
          ))}
        </div>
      ) : (
        <div className="food-empty-state">
          <div
            className="food-empty-state__icon"
            aria-hidden="true"
          >
            🔎
          </div>

          <h2>לא נמצאו מוצרים</h2>

          <p>
            נסה לחפש שם אחר, מותג או קטגוריה.
          </p>

          <button
            type="button"
            onClick={clearFilters}
          >
            נקה את כל הסינונים
          </button>
        </div>
      )}
    </section>
  );
}

type MacroItemProps = {
  label: string;
  value: number;
};

function MacroItem({
  label,
  value,
}: MacroItemProps) {
  return (
    <div className="food-macro">
      <span>{label}</span>
      <strong>{value} גרם</strong>
    </div>
  );
}

const toolbarStyle: CSSProperties = {
  display: "flex",
  alignItems: "stretch",
  gap: "12px",
  marginBottom: "18px",
  flexWrap: "wrap",
};

const searchWrapperStyle: CSSProperties = {
  flex: "1 1 480px",
  marginBottom: 0,
};

const sortContainerStyle: CSSProperties = {
  display: "flex",
  alignItems: "center",
  gap: "10px",
  minHeight: "58px",
  padding: "0 16px",
  border: "1px solid #2B2B2B",
  borderRadius: "18px",
  background: "#161616",
  flex: "0 1 260px",
};

const sortLabelStyle: CSSProperties = {
  color: "#D4AF37",
  fontSize: "13px",
  fontWeight: 700,
  whiteSpace: "nowrap",
};

const sortSelectStyle: CSSProperties = {
  width: "100%",
  border: 0,
  outline: 0,
  background: "transparent",
  color: "#F4F4F4",
  fontFamily: "inherit",
  fontSize: "14px",
  cursor: "pointer",
};

const databaseStatusStyle: CSSProperties = {
  display: "flex",
  alignItems: "center",
  gap: "8px",
  marginTop: "12px",
  color: "#A0A0A0",
  fontSize: "13px",
};

const statusDotStyle: CSSProperties = {
  display: "inline-block",
  width: "8px",
  height: "8px",
  borderRadius: "50%",
};

const importedNoticeStyle: CSSProperties = {
  display: "flex",
  alignItems: "center",
  justifyContent: "space-between",
  gap: "16px",
  marginBottom: "20px",
  padding: "14px 18px",
  border: "1px solid rgba(76, 175, 80, 0.3)",
  borderRadius: "16px",
  background: "rgba(76, 175, 80, 0.07)",
  color: "#A8DDAA",
  fontSize: "14px",
  flexWrap: "wrap",
};

const restoreButtonStyle: CSSProperties = {
  minHeight: "36px",
  padding: "0 14px",
  border: "1px solid #3A3A3A",
  borderRadius: "10px",
  background: "#161616",
  color: "#D0D0D0",
  fontFamily: "inherit",
  fontWeight: 700,
  cursor: "pointer",
};